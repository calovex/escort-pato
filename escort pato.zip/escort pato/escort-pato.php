<?php
/*
Plugin Name: Escort Manager Plugin
Plugin URI: https://example.com
Description: Management plugin for escort directory websites.
Version: 1.0
Author: Your Name
*/

if (!defined('ABSPATH')) {
    exit;
}

/*
========================================
ACTIVATE PLUGIN
========================================
*/

register_activation_hook(__FILE__, 'escort_manager_activate');

function escort_manager_activate() {

    escort_manager_create_roles();

    escort_manager_create_payment_table();

    flush_rewrite_rules();
}


/*
========================================
USER ROLES
========================================
*/

function escort_manager_create_roles() {

    add_role(
        'escort_agent',
        'Escort Support Agent',
        array(
            'read' => true,
            'edit_posts' => true,
            'upload_files' => true,
            'moderate_comments' => true,
        )
    );


    add_role(
        'escort_agency',
        'Escort Agency',
        array(
            'read' => true,
            'upload_files' => true,
        )
    );


    add_role(
        'escort_member',
        'Escort Member',
        array(
            'read' => true,
        )
    );
}


/*
========================================
PAYMENTS TABLE
========================================
*/

function escort_manager_create_payment_table() {

    global $wpdb;

    $table_name = $wpdb->prefix . 'escort_payments';

    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (

        id BIGINT(20) NOT NULL AUTO_INCREMENT,

        user_id BIGINT(20) NOT NULL,

        escort_id BIGINT(20) NOT NULL,

        amount VARCHAR(100),

        payment_method VARCHAR(100),

        transaction_code VARCHAR(255),

        payment_status VARCHAR(50),

        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        PRIMARY KEY (id)

    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

    dbDelta($sql);
}


/*
========================================
ADMIN MENU
========================================
*/

add_action('admin_menu', 'escort_manager_admin_menu');

function escort_manager_admin_menu() {

    add_menu_page(
        'Escort Manager',
        'Escort Manager',
        'manage_options',
        'escort-manager',
        'escort_manager_dashboard_page',
        'dashicons-groups',
        6
    );


    add_submenu_page(
        'escort-manager',
        'Payments',
        'Payments',
        'manage_options',
        'escort-payments',
        'escort_manager_payments_page'
    );


    add_submenu_page(
        'escort-manager',
        'Advertisements',
        'Advertisements',
        'manage_options',
        'escort-adverts',
        'escort_manager_adverts_page'
    );


    add_submenu_page(
        'escort-manager',
        'Support Tickets',
        'Support Tickets',
        'manage_options',
        'escort-tickets',
        'escort_manager_tickets_page'
    );


    add_submenu_page(
        'escort-manager',
        'Settings',
        'Settings',
        'manage_options',
        'escort-settings',
        'escort_manager_settings_page'
    );
}


/*
========================================
DASHBOARD PAGE
========================================
*/

function escort_manager_dashboard_page() {

?>

<div class="wrap">

<h1>Escort Manager Dashboard</h1>

<?php

$escort_count = wp_count_posts('escort')->publish ?? 0;

$agency_count = wp_count_posts('agency')->publish ?? 0;

?>

<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:20px;margin-top:30px;">

<div style="background:#fff;padding:20px;border-radius:10px;">
<h2>Total Escorts</h2>
<h1><?php echo $escort_count; ?></h1>
</div>

<div style="background:#fff;padding:20px;border-radius:10px;">
<h2>Total Agencies</h2>
<h1><?php echo $agency_count; ?></h1>
</div>

<div style="background:#fff;padding:20px;border-radius:10px;">
<h2>Pending Reviews</h2>
<h1>0</h1>
</div>

<div style="background:#fff;padding:20px;border-radius:10px;">
<h2>Revenue</h2>
<h1>KES 0</h1>
</div>

</div>

</div>

<?php
}


/*
========================================
PAYMENTS PAGE
========================================
*/

function escort_manager_payments_page() {

    global $wpdb;

    $table = $wpdb->prefix . 'escort_payments';

    $payments = $wpdb->get_results("SELECT * FROM $table ORDER BY id DESC");

?>

<div class="wrap">

<h1>Payments</h1>

<table class="widefat striped">

<thead>
<tr>
<th>ID</th>
<th>User</th>
<th>Amount</th>
<th>Method</th>
<th>Status</th>
<th>Date</th>
</tr>
</thead>

<tbody>

<?php foreach ($payments as $payment) : ?>

<tr>
<td><?php echo $payment->id; ?></td>
<td><?php echo $payment->user_id; ?></td>
<td><?php echo $payment->amount; ?></td>
<td><?php echo $payment->payment_method; ?></td>
<td><?php echo $payment->payment_status; ?></td>
<td><?php echo $payment->created_at; ?></td>
</tr>

<?php endforeach; ?>

</tbody>

</table>

</div>

<?php
}


/*
========================================
ADVERT POST TYPE
========================================
*/

add_action('init', 'escort_advert_post_type');

function escort_advert_post_type() {

    register_post_type('escort_advert', array(

        'labels' => array(
            'name' => 'Advertisements',
            'singular_name' => 'Advertisement'
        ),

        'public' => false,

        'show_ui' => true,

        'menu_icon' => 'dashicons-megaphone',

        'supports' => array(
            'title',
            'thumbnail'
        )

    ));
}


/*
========================================
ADVERTISEMENT PAGE
========================================
*/

function escort_manager_adverts_page() {

?>

<div class="wrap">

<h1>Advertisement Manager</h1>

<p>
Manage:
</p>

<ul>
<li>Homepage Ads</li>
<li>Sidebar Ads</li>
<li>VIP Promotions</li>
<li>Agency Ads</li>
<li>Banner Campaigns</li>
</ul>

<p>
Use the Advertisements menu to add adverts.
</p>

</div>

<?php
}


/*
========================================
SUPPORT TICKET POST TYPE
========================================
*/

add_action('init', 'escort_ticket_post_type');

function escort_ticket_post_type() {

    register_post_type('support_ticket', array(

        'labels' => array(
            'name' => 'Support Tickets',
            'singular_name' => 'Support Ticket'
        ),

        'public' => false,

        'show_ui' => true,

        'supports' => array(
            'title',
            'editor'
        ),

        'menu_icon' => 'dashicons-sos'

    ));
}


/*
========================================
TICKETS PAGE
========================================
*/

function escort_manager_tickets_page() {

?>

<div class="wrap">

<h1>Support Tickets</h1>

<p>
Manage user complaints, reports and support issues.
</p>

</div>

<?php
}


/*
========================================
SETTINGS PAGE
========================================
*/

function escort_manager_settings_page() {

?>

<div class="wrap">

<h1>Escort Manager Settings</h1>

<form method="post" action="options.php">

<?php
settings_fields('escort_manager_settings_group');
do_settings_sections('escort-settings');
submit_button();
?>

</form>

</div>

<?php
}


/*
========================================
REGISTER SETTINGS
========================================
*/

add_action('admin_init', 'escort_manager_register_settings');

function escort_manager_register_settings() {

    register_setting(
        'escort_manager_settings_group',
        'escort_mpesa_paybill'
    );


    add_settings_section(
        'escort_payment_settings',
        'Payment Settings',
        null,
        'escort-settings'
    );


    add_settings_field(
        'escort_mpesa_paybill',
        'M-Pesa Paybill',
        'escort_mpesa_paybill_callback',
        'escort-settings',
        'escort_payment_settings'
    );
}


function escort_mpesa_paybill_callback() {

    $value = get_option('escort_mpesa_paybill');

?>

<input type="text"
name="escort_mpesa_paybill"
value="<?php echo esc_attr($value); ?>"
class="regular-text">

<?php
}


/*
========================================
VIP / FEATURED BADGES
========================================
*/

function escort_get_badges($post_id) {

    $badges = '';

    if (get_post_meta($post_id, 'vip', true)) {
        $badges .= '<span class="escort-vip-badge">VIP</span> ';
    }

    if (get_post_meta($post_id, 'featured', true)) {
        $badges .= '<span class="escort-featured-badge">Featured</span> ';
    }

    if (get_post_meta($post_id, 'verified', true)) {
        $badges .= '<span class="escort-verified-badge">Verified</span>';
    }

    return $badges;
}


/*
========================================
SHORTCODE - VIP ESCORTS
========================================
*/

add_shortcode('vip_escorts', 'escort_vip_shortcode');

function escort_vip_shortcode() {

    ob_start();

    $args = array(
        'post_type' => 'escort',
        'meta_key' => 'vip',
        'meta_value' => 'on'
    );

    $query = new WP_Query($args);

    if ($query->have_posts()) :

        echo '<div class="escort-vip-grid">';

        while ($query->have_posts()) :

            $query->the_post();

            echo '<div class="escort-vip-card">';

            if (has_post_thumbnail()) {
                the_post_thumbnail('medium');
            }

            echo '<h3>' . get_the_title() . '</h3>';

            echo escort_get_badges(get_the_ID());

            echo '</div>';

        endwhile;

        echo '</div>';

    endif;

    wp_reset_postdata();

    return ob_get_clean();
}


/*
========================================
FRONTEND SUBMISSION SHORTCODE
========================================
*/

add_shortcode('escort_submit_form', 'escort_submit_form_shortcode');

function escort_submit_form_shortcode() {

    if (!is_user_logged_in()) {
        return '<p>You must login first.</p>';
    }

    ob_start();

?>

<form method="post">

<p>
<input type="text"
name="escort_title"
placeholder="Escort Name"
required>
</p>

<p>
<textarea name="escort_description"
placeholder="Description"></textarea>
</p>

<p>
<button type="submit"
name="escort_submit_profile">
Submit Profile
</button>
</p>

</form>

<?php

if (isset($_POST['escort_submit_profile'])) {

    $post_id = wp_insert_post(array(

        'post_type' => 'escort',

        'post_title' => sanitize_text_field($_POST['escort_title']),

        'post_content' => sanitize_textarea_field($_POST['escort_description']),

        'post_status' => 'pending'

    ));


    if ($post_id) {
        echo '<p>Profile submitted successfully.</p>';
    }
}

return ob_get_clean();
}


/*
========================================
FRONTEND DASHBOARD
========================================
*/
add_shortcode(
    'escort_dashboard',
    'escort_dashboard_shortcode'
);

function escort_dashboard_shortcode() {

    if (!is_user_logged_in()) {

        return '

        <div class="escort-login-required">

            <h2>Please Login</h2>

            <p>You must login to access dashboard.</p>

            <a href="' . home_url('/auth') . '"
            class="escort-btn">

                Login

            </a>

        </div>';
    }

    ob_start();

    $tab = isset($_GET['tab'])
        ? sanitize_text_field($_GET['tab'])
        : 'overview';

    ?>

    <div class="escort-dashboard">

        <!-- SIDEBAR -->

        <aside class="escort-sidebar">

            <div class="escort-user-box">

                <h3>
                    <?php echo wp_get_current_user()->display_name; ?>
                </h3>

                <p>
                    Member Dashboard
                </p>

            </div>

            <ul class="escort-menu">

                <li>
                    <a href="?tab=overview"
                    class="<?php echo $tab == 'overview' ? 'active' : ''; ?>">
                        Dashboard
                    </a>
                </li>

                <li>
                    <a href="?tab=profile"
                    class="<?php echo $tab == 'profile' ? 'active' : ''; ?>">
                        My Profile
                    </a>
                </li>

                <li>
                    <a href="?tab=gallery"
                    class="<?php echo $tab == 'gallery' ? 'active' : ''; ?>">
                        Gallery
                    </a>
                </li>

                <li>
                    <a href="?tab=payments"
                    class="<?php echo $tab == 'payments' ? 'active' : ''; ?>">
                        Payments
                    </a>
                </li>

                <li>
                    <a href="?tab=subscription"
                    class="<?php echo $tab == 'subscription' ? 'active' : ''; ?>">
                        Subscription
                    </a>
                </li>

                <li>
                    <a href="?tab=favorites"
                    class="<?php echo $tab == 'favorites' ? 'active' : ''; ?>">
                        Favorites
                    </a>
                </li>

                <li>
                    <a href="<?php echo wp_logout_url(home_url()); ?>">
                        Logout
                    </a>
                </li>

            </ul>

        </aside>

        <!-- MAIN CONTENT -->

        <main class="escort-main">

            <?php

            switch ($tab) {

                case 'profile':
                    escort_dashboard_profile();
                break;

                case 'gallery':
                    escort_dashboard_gallery();
                break;

                case 'payments':
                    escort_dashboard_payments();
                break;

                case 'subscription':
                    escort_dashboard_subscription();
                break;

                case 'favorites':
                    escort_dashboard_favorites();
                break;

                default:
                    escort_dashboard_overview();
                break;
            }

            ?>

        </main>

    </div>

    <?php

    return ob_get_clean();
}

/*
========================================
PROFILE TAB
========================================
*/

function escort_dashboard_profile() {

    $user_id = get_current_user_id();

    ?>

    <h2>
        My Profile
    </h2>

    <form method="post">

        <?php
        wp_nonce_field(
            'escort_profile_update',
            'escort_profile_nonce'
        );
        ?>

        <p>

            <label>
                Display Name
            </label>

            <input
            type="text"
            name="display_name"
            value="<?php echo esc_attr(
                wp_get_current_user()->display_name
            ); ?>">

        </p>

        <p>

            <button
            type="submit"
            name="escort_save_profile">

                Save Profile

            </button>

        </p>

    </form>

    <?php

    /*
    SAVE PROFILE
    */

    if (isset($_POST['escort_save_profile'])) {

        if (
            !isset($_POST['escort_profile_nonce']) ||
            !wp_verify_nonce(
                $_POST['escort_profile_nonce'],
                'escort_profile_update'
            )
        ) {
            return;
        }

        wp_update_user(array(
            'ID' => $user_id,
            'display_name' => sanitize_text_field(
                $_POST['display_name']
            )
        ));

        echo '<p>Profile updated.</p>';
    }
}

/*
========================================
PAYMENTS TAB
========================================
*/

function escort_dashboard_payments() {

    global $wpdb;

    $table = $wpdb->prefix . 'escort_payments';

    $user_id = get_current_user_id();

    $payments = $wpdb->get_results(

        $wpdb->prepare(

            "SELECT * FROM $table
            WHERE user_id = %d
            ORDER BY id DESC",

            $user_id
        )
    );

    ?>

    <h2>
        Payment History
    </h2>

    <table>

        <tr>
            <th>Amount</th>
            <th>Method</th>
            <th>Status</th>
        </tr>

        <?php foreach ($payments as $payment) : ?>

        <tr>

            <td>
                <?php echo esc_html($payment->amount); ?>
            </td>

            <td>
                <?php echo esc_html($payment->payment_method); ?>
            </td>

            <td>
                <?php echo esc_html($payment->payment_status); ?>
            </td>

        </tr>

        <?php endforeach; ?>

    </table>

    <?php
}

function escort_dashboard_subscription() {

    ?>

    <h2>
        Membership Plans
    </h2>

    <div class="escort-plan-grid">

        <div class="escort-plan-card">

            <h3>Free</h3>

            <p>Basic listing</p>

        </div>

        <div class="escort-plan-card">

            <h3>VIP</h3>

            <p>Homepage boost</p>

            <button>
                Upgrade
            </button>

        </div>

    </div>

    <?php
}

function escort_dashboard_overview() {

    $user_id = get_current_user_id();

    $args = array(
        'post_type' => 'escort',
        'author' => $user_id,
        'posts_per_page' => -1
    );

    $query = new WP_Query($args);

    $total_profiles = $query->post_count;

    ?>

    <h2>
        Dashboard Overview
    </h2>

    <div class="escort-dashboard-cards">

        <div class="escort-card">

            <h3>
                My Profiles
            </h3>

            <p>
                <?php echo $total_profiles; ?>
            </p>

        </div>

        <div class="escort-card">

            <h3>
                Total Views
            </h3>

            <p>
                0
            </p>

        </div>

        <div class="escort-card">

            <h3>
                Favorites
            </h3>

            <p>
                0
            </p>

        </div>

        <div class="escort-card">

            <h3>
                Membership
            </h3>

            <p>
                Free
            </p>

        </div>

    </div>

    <?php
}


function escort_dashboard_gallery() {

    echo '<h2>Gallery</h2>';

    echo '<p>Gallery system coming next.</p>';
}

function escort_dashboard_favorites() {

    echo '<h2>Favorites</h2>';

    echo '<p>Favorites system coming next.</p>';
}

/*
========================================
AUTH SYSTEM
========================================
*/

add_shortcode(
    'escort_auth',
    'escort_auth_shortcode'
);

function escort_auth_shortcode() {

    if (is_user_logged_in()) {

        wp_redirect(home_url('/dashboard'));

        exit;
    }

    ob_start();

    ?>

    <div class="escort-auth-wrapper">

        <div class="escort-auth-grid">

            <!-- LOGIN -->

            <div class="escort-auth-box">

                <h2>
                    Login
                </h2>

                <?php escort_login_form(); ?>

            </div>

            <!-- REGISTER -->

            <div class="escort-auth-box">

                <h2>
                    Register
                </h2>

                <?php escort_register_form(); ?>

            </div>

        </div>

    </div>

    <?php

    return ob_get_clean();
}


function escort_login_form() {

    if (isset($_POST['escort_login'])) {

        escort_handle_login();
    }

    ?>

    <form method="post">

        <?php
        wp_nonce_field(
            'escort_login_action',
            'escort_login_nonce'
        );
        ?>

        <p>

            <input
            type="text"
            name="username"
            placeholder="Username or Email"
            required>

        </p>

        <p>

            <input
            type="password"
            name="password"
            placeholder="Password"
            required>

        </p>

        <p>

            <button
            type="submit"
            name="escort_login">

                Login

            </button>

        </p>

    </form>

    <?php
}

function escort_handle_login() {

    if (
        !isset($_POST['escort_login_nonce']) ||
        !wp_verify_nonce(
            $_POST['escort_login_nonce'],
            'escort_login_action'
        )
    ) {

        echo '<p>Security check failed.</p>';

        return;
    }

    $creds = array(

        'user_login' => sanitize_text_field(
            $_POST['username']
        ),

        'user_password' => $_POST['password'],

        'remember' => true
    );

    $user = wp_signon($creds, false);

    if (is_wp_error($user)) {

        echo '<p>Invalid login details.</p>';

    } else {

        wp_redirect(home_url('/dashboard'));

        exit;
    }
}

function escort_register_form() {

    if (isset($_POST['escort_register'])) {

        escort_handle_register();
    }

    ?>

    <form method="post">

        <?php
        wp_nonce_field(
            'escort_register_action',
            'escort_register_nonce'
        );
        ?>

        <p>

            <input
            type="text"
            name="username"
            placeholder="Username"
            required>

        </p>

        <p>

            <input
            type="email"
            name="email"
            placeholder="Email"
            required>

        </p>

        <p>

            <input
            type="password"
            name="password"
            placeholder="Password"
            required>

        </p>

        <p>

            <button
            type="submit"
            name="escort_register">

                Register

            </button>

        </p>

    </form>

    <?php
}

function escort_handle_register() {

    if (
        !isset($_POST['escort_register_nonce']) ||
        !wp_verify_nonce(
            $_POST['escort_register_nonce'],
            'escort_register_action'
        )
    ) {

        echo '<p>Security check failed.</p>';

        return;
    }

    $username = sanitize_user($_POST['username']);

    $email = sanitize_email($_POST['email']);

    $password = $_POST['password'];

    if (username_exists($username)) {

        echo '<p>Username already exists.</p>';

        return;
    }

    if (email_exists($email)) {

        echo '<p>Email already exists.</p>';

        return;
    }

    $user_id = wp_create_user(
        $username,
        $password,
        $email
    );

    if (is_wp_error($user_id)) {

        echo '<p>Registration failed.</p>';

        return;
    }

    /*
    SET ROLE
    */

    $user = new WP_User($user_id);

    $user->set_role('escort_member');

    /*
    AUTO LOGIN
    */

    wp_set_current_user($user_id);

    wp_set_auth_cookie($user_id);

    wp_redirect(home_url('/dashboard'));

    exit;
}
?>



