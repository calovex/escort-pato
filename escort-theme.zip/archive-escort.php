<?php get_header(); ?>
<h1 class="text-xl font-bold p-4">Escort Listings</h1>
<div class="grid grid-cols-2 md:grid-cols-3 gap-4 p-4">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div class="bg-white shadow rounded">
<?php the_post_thumbnail('medium'); ?>
<div class="p-2">
<h2><?php the_title(); ?></h2>
<p><?php the_field('location'); ?></p>
<a href="<?php the_permalink(); ?>">View</a>
</div>
</div>
<?php endwhile; endif; ?>
</div>
<?php get_footer(); ?>
