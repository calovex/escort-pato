<?php get_header(); ?>
<section class="p-4">
<h2 class="text-lg font-bold mb-3">All Escorts</h2>
<div class="grid grid-cols-2 md:grid-cols-3 gap-4">
<?php
$args = array('post_type' => 'escort');
$query = new WP_Query($args);
if ($query->have_posts()) :
while ($query->have_posts()) : $query->the_post();
?>
<div class="bg-white rounded shadow">
<?php if (has_post_thumbnail()) : the_post_thumbnail('medium', ['class'=>'rounded-t']); endif; ?>
<div class="p-2">
<h3 class="font-bold"><?php the_title(); ?></h3>
<p class="text-sm">📍 <?php the_field('location'); ?></p>
<p class="text-green-600">KES <?php the_field('price'); ?></p>
<a href="<?php the_permalink(); ?>" class="block bg-pink-500 text-white text-center mt-2 p-1 rounded">View Profile</a>
</div>
</div>
<?php endwhile; endif; wp_reset_postdata(); ?>
</div>
</section>
<?php get_footer(); ?>
