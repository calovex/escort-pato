<footer class="bg-white text-center p-4 mt-6">
<p>© <?php echo date('Y'); ?> EscortSite</p>
</footer>
<?php wp_footer(); ?>
</body>
</html>
