<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class('bg-gray-100'); ?>>
<header class="bg-white shadow p-4 flex justify-between">
<h1 class="text-xl font-bold"><a href="<?php echo home_url(); ?>">EscortSite</a></h1>
<nav><a href="<?php echo home_url('/escorts'); ?>">Escorts</a></nav>
</header>
