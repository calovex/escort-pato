<?php
function escort_theme_scripts() {
    wp_enqueue_script('tailwind', 'https://cdn.tailwindcss.com');
}
add_action('wp_enqueue_scripts', 'escort_theme_scripts');

function create_escort_post_type() {
    register_post_type('escort',
        array(
            'labels' => array(
                'name' => __('Escorts'),
                'singular_name' => __('Escort')
            ),
            'public' => true,
            'has_archive' => true,
            'rewrite' => array('slug' => 'escorts'),
            'supports' => array('title', 'editor', 'thumbnail')
        )
    );
}
add_action('init', 'create_escort_post_type');
?>
