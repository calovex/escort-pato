<?php get_header(); ?>
<div class="max-w-4xl mx-auto bg-white p-4 shadow mt-4">
<?php if (has_post_thumbnail()) : the_post_thumbnail('large', ['class'=>'w-full rounded']); endif; ?>
<h1 class="text-2xl font-bold mt-3"><?php the_title(); ?></h1>
<p>📍 <?php the_field('location'); ?></p>
<div class="flex gap-2 mt-2">
<?php if (get_field('verified')) : ?><span class="bg-green-200 px-2 rounded">Verified</span><?php endif; ?>
<?php if (get_field('vip')) : ?><span class="bg-yellow-200 px-2 rounded">VIP</span><?php endif; ?>
</div>
<div class="mt-3">
<p>Incall: KES <?php the_field('incall_price'); ?></p>
<p>Outcall: KES <?php the_field('outcall_price'); ?></p>
</div>
<div class="mt-4 flex gap-2">
<a href="tel:<?php the_field('phone'); ?>" class="bg-green-500 text-white px-4 py-2 rounded">Call</a>
<a href="https://wa.me/<?php the_field('phone'); ?>" class="bg-green-600 text-white px-4 py-2 rounded">WhatsApp</a>
</div>
<div class="mt-4"><?php the_content(); ?></div>
</div>
<?php get_footer(); ?>
